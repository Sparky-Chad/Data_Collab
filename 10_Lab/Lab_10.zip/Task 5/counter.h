#ifndef COUNTER_H
#define COUNTER_H

// This class is built to just provide some excess code for the testing
// which is required by the rest of the code. By Defining the counter within
// here it saves some time later on when it comes to trying to find out how to
// implement everything

// Define the proper iterator which is then used to tell whether they should run everything
#define COUNTER

// Variables to store the spots searched for by the two data structures
// and then can store and output whatever that number amounts to
int searchspot = 0;
int hashspot = 0;
int binaryspot = 0;


#endif